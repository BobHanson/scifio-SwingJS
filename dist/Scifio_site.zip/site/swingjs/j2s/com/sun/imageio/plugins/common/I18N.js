(function(){var P$=Clazz.newPackage("com.sun.imageio.plugins.common"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "I18N", null, 'com.sun.imageio.plugins.common.I18NImpl');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getString$S', function (key) {
return P$.I18NImpl.getString$S$S$S("com.sun.imageio.plugins.common.I18N", "iio-plugin.properties", key);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.7-v3');//Created 2020-01-18 17:07:25 Java2ScriptVisitor version 3.2.7-v3 net.sf.j2s.core.jar version 3.2.7-v3
