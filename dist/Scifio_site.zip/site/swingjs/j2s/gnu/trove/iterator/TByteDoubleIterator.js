(function(){var P$=Clazz.newPackage("gnu.trove.iterator"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "TByteDoubleIterator", null, null, 'gnu.trove.iterator.TAdvancingIterator');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.7-v3');//Created 2020-01-20 12:40:24 Java2ScriptVisitor version 3.2.7-v3 net.sf.j2s.core.jar version 3.2.7-v3
