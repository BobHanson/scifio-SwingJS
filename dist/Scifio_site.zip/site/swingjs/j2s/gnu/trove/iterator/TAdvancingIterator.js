(function(){var P$=Clazz.newPackage("gnu.trove.iterator"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "TAdvancingIterator", null, null, 'gnu.trove.iterator.TIterator');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.6-v1');//Created 2020-01-01 11:49:46 Java2ScriptVisitor version 3.2.6-v1 net.sf.j2s.core.jar version 3.2.6-v1
