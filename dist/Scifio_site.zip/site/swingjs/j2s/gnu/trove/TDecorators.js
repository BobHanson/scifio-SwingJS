(function(){var P$=Clazz.newPackage("gnu.trove"),I$=[[0,'gnu.trove.decorator.TDoubleDoubleMapDecorator','gnu.trove.decorator.TDoubleFloatMapDecorator','gnu.trove.decorator.TDoubleIntMapDecorator','gnu.trove.decorator.TDoubleLongMapDecorator','gnu.trove.decorator.TDoubleByteMapDecorator','gnu.trove.decorator.TDoubleShortMapDecorator','gnu.trove.decorator.TDoubleCharMapDecorator','gnu.trove.decorator.TFloatDoubleMapDecorator','gnu.trove.decorator.TFloatFloatMapDecorator','gnu.trove.decorator.TFloatIntMapDecorator','gnu.trove.decorator.TFloatLongMapDecorator','gnu.trove.decorator.TFloatByteMapDecorator','gnu.trove.decorator.TFloatShortMapDecorator','gnu.trove.decorator.TFloatCharMapDecorator','gnu.trove.decorator.TIntDoubleMapDecorator','gnu.trove.decorator.TIntFloatMapDecorator','gnu.trove.decorator.TIntIntMapDecorator','gnu.trove.decorator.TIntLongMapDecorator','gnu.trove.decorator.TIntByteMapDecorator','gnu.trove.decorator.TIntShortMapDecorator','gnu.trove.decorator.TIntCharMapDecorator','gnu.trove.decorator.TLongDoubleMapDecorator','gnu.trove.decorator.TLongFloatMapDecorator','gnu.trove.decorator.TLongIntMapDecorator','gnu.trove.decorator.TLongLongMapDecorator','gnu.trove.decorator.TLongByteMapDecorator','gnu.trove.decorator.TLongShortMapDecorator','gnu.trove.decorator.TLongCharMapDecorator','gnu.trove.decorator.TByteDoubleMapDecorator','gnu.trove.decorator.TByteFloatMapDecorator','gnu.trove.decorator.TByteIntMapDecorator','gnu.trove.decorator.TByteLongMapDecorator','gnu.trove.decorator.TByteByteMapDecorator','gnu.trove.decorator.TByteShortMapDecorator','gnu.trove.decorator.TByteCharMapDecorator','gnu.trove.decorator.TShortDoubleMapDecorator','gnu.trove.decorator.TShortFloatMapDecorator','gnu.trove.decorator.TShortIntMapDecorator','gnu.trove.decorator.TShortLongMapDecorator','gnu.trove.decorator.TShortByteMapDecorator','gnu.trove.decorator.TShortShortMapDecorator','gnu.trove.decorator.TShortCharMapDecorator','gnu.trove.decorator.TCharDoubleMapDecorator','gnu.trove.decorator.TCharFloatMapDecorator','gnu.trove.decorator.TCharIntMapDecorator','gnu.trove.decorator.TCharLongMapDecorator','gnu.trove.decorator.TCharByteMapDecorator','gnu.trove.decorator.TCharShortMapDecorator','gnu.trove.decorator.TCharCharMapDecorator','gnu.trove.decorator.TObjectDoubleMapDecorator','gnu.trove.decorator.TObjectFloatMapDecorator','gnu.trove.decorator.TObjectIntMapDecorator','gnu.trove.decorator.TObjectLongMapDecorator','gnu.trove.decorator.TObjectByteMapDecorator','gnu.trove.decorator.TObjectShortMapDecorator','gnu.trove.decorator.TObjectCharMapDecorator','gnu.trove.decorator.TDoubleObjectMapDecorator','gnu.trove.decorator.TFloatObjectMapDecorator','gnu.trove.decorator.TIntObjectMapDecorator','gnu.trove.decorator.TLongObjectMapDecorator','gnu.trove.decorator.TByteObjectMapDecorator','gnu.trove.decorator.TShortObjectMapDecorator','gnu.trove.decorator.TCharObjectMapDecorator','gnu.trove.decorator.TDoubleSetDecorator','gnu.trove.decorator.TFloatSetDecorator','gnu.trove.decorator.TIntSetDecorator','gnu.trove.decorator.TLongSetDecorator','gnu.trove.decorator.TByteSetDecorator','gnu.trove.decorator.TShortSetDecorator','gnu.trove.decorator.TCharSetDecorator','gnu.trove.decorator.TDoubleListDecorator','gnu.trove.decorator.TFloatListDecorator','gnu.trove.decorator.TIntListDecorator','gnu.trove.decorator.TLongListDecorator','gnu.trove.decorator.TByteListDecorator','gnu.trove.decorator.TShortListDecorator','gnu.trove.decorator.TCharListDecorator']],$I$=function(i,n){return(i=(I$[i]||(I$[i]=Clazz.load(I$[0][i])))),!n&&i.$load$&&Clazz.load(i,2),i};
/*c*/var C$=Clazz.newClass(P$, "TDecorators");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$', function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleDoubleMap', function (map) {
return Clazz.new_($I$(1,1).c$$gnu_trove_map_TDoubleDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleFloatMap', function (map) {
return Clazz.new_($I$(2,1).c$$gnu_trove_map_TDoubleFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleIntMap', function (map) {
return Clazz.new_($I$(3,1).c$$gnu_trove_map_TDoubleIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleLongMap', function (map) {
return Clazz.new_($I$(4,1).c$$gnu_trove_map_TDoubleLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleByteMap', function (map) {
return Clazz.new_($I$(5,1).c$$gnu_trove_map_TDoubleByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleShortMap', function (map) {
return Clazz.new_($I$(6,1).c$$gnu_trove_map_TDoubleShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleCharMap', function (map) {
return Clazz.new_($I$(7,1).c$$gnu_trove_map_TDoubleCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatDoubleMap', function (map) {
return Clazz.new_($I$(8,1).c$$gnu_trove_map_TFloatDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatFloatMap', function (map) {
return Clazz.new_($I$(9,1).c$$gnu_trove_map_TFloatFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatIntMap', function (map) {
return Clazz.new_($I$(10,1).c$$gnu_trove_map_TFloatIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatLongMap', function (map) {
return Clazz.new_($I$(11,1).c$$gnu_trove_map_TFloatLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatByteMap', function (map) {
return Clazz.new_($I$(12,1).c$$gnu_trove_map_TFloatByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatShortMap', function (map) {
return Clazz.new_($I$(13,1).c$$gnu_trove_map_TFloatShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatCharMap', function (map) {
return Clazz.new_($I$(14,1).c$$gnu_trove_map_TFloatCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntDoubleMap', function (map) {
return Clazz.new_($I$(15,1).c$$gnu_trove_map_TIntDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntFloatMap', function (map) {
return Clazz.new_($I$(16,1).c$$gnu_trove_map_TIntFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntIntMap', function (map) {
return Clazz.new_($I$(17,1).c$$gnu_trove_map_TIntIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntLongMap', function (map) {
return Clazz.new_($I$(18,1).c$$gnu_trove_map_TIntLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntByteMap', function (map) {
return Clazz.new_($I$(19,1).c$$gnu_trove_map_TIntByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntShortMap', function (map) {
return Clazz.new_($I$(20,1).c$$gnu_trove_map_TIntShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntCharMap', function (map) {
return Clazz.new_($I$(21,1).c$$gnu_trove_map_TIntCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongDoubleMap', function (map) {
return Clazz.new_($I$(22,1).c$$gnu_trove_map_TLongDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongFloatMap', function (map) {
return Clazz.new_($I$(23,1).c$$gnu_trove_map_TLongFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongIntMap', function (map) {
return Clazz.new_($I$(24,1).c$$gnu_trove_map_TLongIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongLongMap', function (map) {
return Clazz.new_($I$(25,1).c$$gnu_trove_map_TLongLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongByteMap', function (map) {
return Clazz.new_($I$(26,1).c$$gnu_trove_map_TLongByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongShortMap', function (map) {
return Clazz.new_($I$(27,1).c$$gnu_trove_map_TLongShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongCharMap', function (map) {
return Clazz.new_($I$(28,1).c$$gnu_trove_map_TLongCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteDoubleMap', function (map) {
return Clazz.new_($I$(29,1).c$$gnu_trove_map_TByteDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteFloatMap', function (map) {
return Clazz.new_($I$(30,1).c$$gnu_trove_map_TByteFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteIntMap', function (map) {
return Clazz.new_($I$(31,1).c$$gnu_trove_map_TByteIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteLongMap', function (map) {
return Clazz.new_($I$(32,1).c$$gnu_trove_map_TByteLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteByteMap', function (map) {
return Clazz.new_($I$(33,1).c$$gnu_trove_map_TByteByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteShortMap', function (map) {
return Clazz.new_($I$(34,1).c$$gnu_trove_map_TByteShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteCharMap', function (map) {
return Clazz.new_($I$(35,1).c$$gnu_trove_map_TByteCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortDoubleMap', function (map) {
return Clazz.new_($I$(36,1).c$$gnu_trove_map_TShortDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortFloatMap', function (map) {
return Clazz.new_($I$(37,1).c$$gnu_trove_map_TShortFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortIntMap', function (map) {
return Clazz.new_($I$(38,1).c$$gnu_trove_map_TShortIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortLongMap', function (map) {
return Clazz.new_($I$(39,1).c$$gnu_trove_map_TShortLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortByteMap', function (map) {
return Clazz.new_($I$(40,1).c$$gnu_trove_map_TShortByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortShortMap', function (map) {
return Clazz.new_($I$(41,1).c$$gnu_trove_map_TShortShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortCharMap', function (map) {
return Clazz.new_($I$(42,1).c$$gnu_trove_map_TShortCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharDoubleMap', function (map) {
return Clazz.new_($I$(43,1).c$$gnu_trove_map_TCharDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharFloatMap', function (map) {
return Clazz.new_($I$(44,1).c$$gnu_trove_map_TCharFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharIntMap', function (map) {
return Clazz.new_($I$(45,1).c$$gnu_trove_map_TCharIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharLongMap', function (map) {
return Clazz.new_($I$(46,1).c$$gnu_trove_map_TCharLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharByteMap', function (map) {
return Clazz.new_($I$(47,1).c$$gnu_trove_map_TCharByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharShortMap', function (map) {
return Clazz.new_($I$(48,1).c$$gnu_trove_map_TCharShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharCharMap', function (map) {
return Clazz.new_($I$(49,1).c$$gnu_trove_map_TCharCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TObjectDoubleMap', function (map) {
return Clazz.new_($I$(50,1).c$$gnu_trove_map_TObjectDoubleMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TObjectFloatMap', function (map) {
return Clazz.new_($I$(51,1).c$$gnu_trove_map_TObjectFloatMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TObjectIntMap', function (map) {
return Clazz.new_($I$(52,1).c$$gnu_trove_map_TObjectIntMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TObjectLongMap', function (map) {
return Clazz.new_($I$(53,1).c$$gnu_trove_map_TObjectLongMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TObjectByteMap', function (map) {
return Clazz.new_($I$(54,1).c$$gnu_trove_map_TObjectByteMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TObjectShortMap', function (map) {
return Clazz.new_($I$(55,1).c$$gnu_trove_map_TObjectShortMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TObjectCharMap', function (map) {
return Clazz.new_($I$(56,1).c$$gnu_trove_map_TObjectCharMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TDoubleObjectMap', function (map) {
return Clazz.new_($I$(57,1).c$$gnu_trove_map_TDoubleObjectMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TFloatObjectMap', function (map) {
return Clazz.new_($I$(58,1).c$$gnu_trove_map_TFloatObjectMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TIntObjectMap', function (map) {
return Clazz.new_($I$(59,1).c$$gnu_trove_map_TIntObjectMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TLongObjectMap', function (map) {
return Clazz.new_($I$(60,1).c$$gnu_trove_map_TLongObjectMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TByteObjectMap', function (map) {
return Clazz.new_($I$(61,1).c$$gnu_trove_map_TByteObjectMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TShortObjectMap', function (map) {
return Clazz.new_($I$(62,1).c$$gnu_trove_map_TShortObjectMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_map_TCharObjectMap', function (map) {
return Clazz.new_($I$(63,1).c$$gnu_trove_map_TCharObjectMap,[map]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_set_TDoubleSet', function (set) {
return Clazz.new_($I$(64,1).c$$gnu_trove_set_TDoubleSet,[set]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_set_TFloatSet', function (set) {
return Clazz.new_($I$(65,1).c$$gnu_trove_set_TFloatSet,[set]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_set_TIntSet', function (set) {
return Clazz.new_($I$(66,1).c$$gnu_trove_set_TIntSet,[set]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_set_TLongSet', function (set) {
return Clazz.new_($I$(67,1).c$$gnu_trove_set_TLongSet,[set]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_set_TByteSet', function (set) {
return Clazz.new_($I$(68,1).c$$gnu_trove_set_TByteSet,[set]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_set_TShortSet', function (set) {
return Clazz.new_($I$(69,1).c$$gnu_trove_set_TShortSet,[set]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_set_TCharSet', function (set) {
return Clazz.new_($I$(70,1).c$$gnu_trove_set_TCharSet,[set]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_list_TDoubleList', function (list) {
return Clazz.new_($I$(71,1).c$$gnu_trove_list_TDoubleList,[list]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_list_TFloatList', function (list) {
return Clazz.new_($I$(72,1).c$$gnu_trove_list_TFloatList,[list]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_list_TIntList', function (list) {
return Clazz.new_($I$(73,1).c$$gnu_trove_list_TIntList,[list]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_list_TLongList', function (list) {
return Clazz.new_($I$(74,1).c$$gnu_trove_list_TLongList,[list]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_list_TByteList', function (list) {
return Clazz.new_($I$(75,1).c$$gnu_trove_list_TByteList,[list]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_list_TShortList', function (list) {
return Clazz.new_($I$(76,1).c$$gnu_trove_list_TShortList,[list]);
}, 1);

Clazz.newMeth(C$, 'wrap$gnu_trove_list_TCharList', function (list) {
return Clazz.new_($I$(77,1).c$$gnu_trove_list_TCharList,[list]);
}, 1);
})();
;Clazz.setTVer('3.2.7-v3');//Created 2020-01-20 12:40:14 Java2ScriptVisitor version 3.2.7-v3 net.sf.j2s.core.jar version 3.2.7-v3
