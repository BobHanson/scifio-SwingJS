(function(){var P$=Clazz.newPackage("gnu.trove"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "TFloatCollection");
})();
;Clazz.setTVer('3.2.6-v1');//Created 2020-01-01 11:49:33 Java2ScriptVisitor version 3.2.6-v1 net.sf.j2s.core.jar version 3.2.6-v1
