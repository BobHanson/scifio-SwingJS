(function(){var P$=Clazz.newPackage("io.scif.formats"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ICSFormat", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'io.scif.AbstractFormat');
C$.$classes$=[['Reader',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ICSFormat, "Reader", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'io.scif.formats.AbstractReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
}, 1);

Clazz.newMeth(C$, ['openPlane$I$io_scif_formats_ByteArrayPlane$I','openPlane$I$TP$I'], function (i, plane, j) {
return null;
});

Clazz.newMeth(C$, ['openPlane$io_scif_formats_ByteArrayPlane','openPlane$TP'], function (plane) {
return null;
});

Clazz.newMeth(C$, ['openPlane$io_scif_formats_ByteArrayPlane$io_scif_formats_SCIFIOConfig','openPlane$TP$io_scif_formats_SCIFIOConfig'], function (plane, config) {
return null;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.2.6-v1');//Created 2020-01-03 19:47:57 Java2ScriptVisitor version 3.2.6-v1 net.sf.j2s.core.jar version 3.2.6-v1
