(function(){var P$=Clazz.newPackage("gnu.trove.iterator"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "TByteLongIterator", null, null, 'gnu.trove.iterator.TAdvancingIterator');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-29 13:46:21 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
