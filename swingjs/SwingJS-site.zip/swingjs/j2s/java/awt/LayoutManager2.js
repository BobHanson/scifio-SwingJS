(function(){var P$=Clazz.newPackage("java.awt"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "LayoutManager2", null, null, 'java.awt.LayoutManager');

C$.$clinit$=2;
})();
;Clazz.setTVer('3.2.6-v0');//Created 2019-12-27 11:04:39 Java2ScriptVisitor version 3.2.6-v0 net.sf.j2s.core.jar version 3.2.6-v0
